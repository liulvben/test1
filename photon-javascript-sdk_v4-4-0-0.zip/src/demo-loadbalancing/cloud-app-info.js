﻿
var AppInfo = {
//	Wss: true,
    AppId: "<no-app-id>",
    AppVersion: "1.0",
//	MasterServer: "localhost:9090"
//  NameServer: "ws://localhost:9093"
//  FbAppId: "you fb app id", 
}

